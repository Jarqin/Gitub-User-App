package com.example.githubuserapi

data class UserRespond(
    val items : ArrayList<User>
)
