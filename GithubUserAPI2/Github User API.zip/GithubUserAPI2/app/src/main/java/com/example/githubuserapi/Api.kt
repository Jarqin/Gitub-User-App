package com.example.githubuserapi

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface Api {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUser(
        @Query("q") query: String
    ): Call<UserRespond>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getUserDetail(
        @Path("username") username :String
    ): Call<DetailUserRespond>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getFollowers(
        @Path("username") username :String
    ): Call<ArrayList<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getFollowing(
        @Path("username") username :String
    ): Call<ArrayList<User>>
}